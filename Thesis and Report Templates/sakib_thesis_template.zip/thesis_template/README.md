# Thesis LaTeX Template
## Professional Academic Thesis Template

---

## Folder Structure

```
thesis_template/
├── main.tex                    ← ENTRY POINT — compile this file
├── references.bib              ← All bibliography entries
├── README.md                   ← This file
│
├── frontmatter/
│   ├── titlepage.tex           ← Title page
│   ├── declaration.tex         ← Declaration of originality
│   ├── approval.tex            ← Supervisor / examiner approval
│   ├── abstract.tex            ← Abstract + keywords
│   ├── acknowledgements.tex    ← Acknowledgements
│   └── acronyms.tex            ← Acronyms and abbreviations
│
├── chapters/
│   ├── 01_introduction.tex
│   ├── 02_literature_review.tex
│   ├── 03_problem_statement.tex
│   ├── 04_methodology.tex
│   ├── 05_implementation.tex
│   ├── 06_results.tex
│   ├── 07_discussion.tex
│   ├── 08_conclusion.tex
│   ├── appendix_a.tex
│   └── appendix_b.tex
│
└── figures/                    ← Put ALL images here (png, jpg, pdf)
```

---

## How to Compile

### Option 1 — Overleaf (recommended for beginners)
1. Zip the entire `thesis_template/` folder
2. Upload to [overleaf.com](https://www.overleaf.com) → New Project → Upload Project
3. Set **compiler** to `pdfLaTeX`
4. Set **main document** to `main.tex`
5. Click **Compile**

### Option 2 — Local (VS Code + LaTeX Workshop)
Install: `TeX Live` (Linux/Mac) or `MiKTeX` (Windows), then `VS Code` + `LaTeX Workshop` extension.
```
pdflatex  main.tex
biber     main
pdflatex  main.tex
pdflatex  main.tex
```

### Option 3 — Command Line (full build)
```bash
pdflatex  main
biber     main
makeglossaries main
pdflatex  main
pdflatex  main
```

---

## Customization Checklist

### Step 1 — Update your details in `main.tex`
Find these lines near the top and fill in your info:
```latex
\newcommand{\thesistitle}{Thesis Title Goes Here}
\newcommand{\theauthor}{Your Full Name}
\newcommand{\thestudentid}{STUDENT-ID}
\newcommand{\thedegree}{Bachelor of Science in Computer Science & Engineering}
\newcommand{\thedepartment}{Department of Computer Science & Engineering}
\newcommand{\theuniversity}{University Name}
\newcommand{\thesupervisor}{Supervisor Name}
\newcommand{\thesubmissiondate}{Month Year}
```

### Step 2 — Add your university logo
- Place `logo.png` in the `figures/` folder
- In `frontmatter/titlepage.tex`, uncomment:
  ```latex
  \includegraphics[width=4cm]{logo.png}
  ```

### Step 3 — Replace dummy text
- Search for `\lipsum[...]` in all chapter files
- Replace with your actual content

### Step 4 — Add your figures
- Place all images (PNG, JPG, PDF) inside the `figures/` folder
- Reference them as: `\includegraphics[width=0.8\textwidth]{your_figure.png}`

### Step 5 — Update bibliography
- Edit `references.bib` with your real citations
- Delete the placeholder entries (`example-reference-1`, etc.)

### Step 6 — Add/edit acronyms
- Edit `frontmatter/acronyms.tex`
- Use `\gls{rnn}` in your text (first use expands automatically)

---

## Changing Bibliography Style

In `main.tex`, find:
```latex
\usepackage[backend=biber, style=ieee, ...]
```
Change `style=ieee` to:
- `style=authoryear` — (Author, Year) citations
- `style=apa` — APA format
- `style=numeric` — [1], [2], [3]
- `style=chicago-authordate` — Chicago style

---

## Adding / Removing Chapters

To add a new chapter, create `chapters/09_new_chapter.tex` and add to `main.tex`:
```latex
\input{chapters/09_new_chapter}
```

To remove a chapter, comment out its `\input` line in `main.tex`.

---

## Line Spacing

In `main.tex`:
- `\onehalfspacing` — 1.5 line spacing (default)
- `\doublespacing` — double spacing
- `\singlespacing` — single spacing

---

## Tips

- Keep one sentence per line in your `.tex` files (easier git diffs)
- Use `\label{chap:name}` and `\ref{chap:name}` for cross-references
- Use `\cite{key}` for citations
- Put all images in `figures/` — never reference absolute paths
- Compile at least **twice** after adding new `\label` or `\cite` entries
