Place all your images (PNG, JPG, PDF) in this folder.

Reference them in LaTeX as:
  \includegraphics[width=0.8\textwidth]{your_image_name.png}

Do NOT include the path prefix — LaTeX finds files here automatically
because main.tex contains:  \graphicspath{{figures/}}

Examples:
  \includegraphics[width=\textwidth]{pipeline.png}
  \includegraphics[width=0.6\textwidth]{confusion_matrix.pdf}
  \includegraphics[width=4cm]{logo.png}
